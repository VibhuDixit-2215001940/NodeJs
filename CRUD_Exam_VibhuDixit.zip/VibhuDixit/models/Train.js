const mongoose = require('mongoose');

const trainSchema = new mongoose.Schema({
    trainName:{
        type: String,
        required: true
    },
    time:{
        type: Date,
        required: true
    },
    timestamps:{
        type: Date,
        default: Date.now
    }
});

let Train = mongoose.model('Train',trainSchema);
module.exports = Train;