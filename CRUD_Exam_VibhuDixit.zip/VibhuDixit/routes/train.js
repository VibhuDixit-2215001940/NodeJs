const express = require('express');
const router = express.Router();
const Train = require('../models/Train')

router.get('/train',async (req,res)=>{
    const trains = await Train.find({});
    res.render('Train/index.ejs',{trains})
})
router.get('/train/:id',async (req,res)=>{
    const train = await Train.findById(req.params.id);
    if(!train){
        return res.status(404).send('Train not found')
    }
    res.render('Train/show.ejs',{train})
})
router.get('/create',(req,res)=>{
    res.render('Train/create.ejs')
})
router.post('/create',async(req,res)=>{
    const {trainName,time,timestamps} = req.body;
    const train = new Train({trainName,time,timestamps});
    await train.save()
    res.redirect('/train')
})
router.post('/train/:id/delete',async(req,res)=>{
    const train = await Train.findByIdAndDelete(req.params.id);
    res.redirect('/train')
    })
module.exports = router;